﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class CentroDeAtencion
    {

        private int cantRacsPorSuper;
        private List<Empleado> empleados;
        private string nombre;

        public CentroDeAtencion(string nombre,int cantRacsPorSuper )
        {
            this.cantRacsPorSuper = cantRacsPorSuper;
            this.nombre = nombre;
            this.empleados = new List<Empleado>();
        }

        public string Nombre
        {
            get
            {
                return this.nombre;
            }
        }
        public int CantRacsPorSuper
        {
            get
            {
                return this.cantRacsPorSuper;
            }
        }
        public List<Empleado> Empleados
        {
            get
            {
                return this.empleados;
            }
        }

        public static bool operator ==(CentroDeAtencion centro, Empleado empleado)
        {
            return centro.empleados.Contains(empleado);
        }

        public static bool operator !=(CentroDeAtencion centro, Empleado empleado)
        {
            return !(centro == empleado);
        }

        private bool ValidaCantidadDeRacs()
        {
            int countSupervisores = 0;
            int countRacs = 0;

            foreach (Empleado emp in empleados)
            {
                if (emp is Supervisor)
                {
                    countSupervisores++;
                }
                else if (emp is Rac)
                {
                    countRacs++;
                }
            }

            return countRacs > 0 && countRacs % cantRacsPorSuper == 0 && countRacs / cantRacsPorSuper == countSupervisores;
        }

        public static bool operator +(CentroDeAtencion centro, Empleado empleado)
        {
            if (centro.empleados.Contains(empleado))
            {
                return false; 
            }

            if (empleado is Supervisor && centro.ValidaCantidadDeRacs())
            {
                centro.empleados.Add(empleado);
                return true; 
            }

            if (!(empleado is Supervisor))
            {
                centro.empleados.Add(empleado);
                return true; 
            }

            return false;  
        }

        public static string operator -(CentroDeAtencion centro, Empleado empleado)
        {
            if (centro == empleado)
            {
                empleado.HoraEgreso = DateTime.Now.TimeOfDay;
                string factura = empleado.EmitirFactura();
                centro.empleados.Remove(empleado);
                return factura;
            }
            else
            {
                return "Empleado no encontrado";
            }
        }

        public string ImprimirNomina()
        {
            StringBuilder sb = new StringBuilder();
            foreach (Empleado emp in empleados)
            {
                sb.AppendLine(emp.ToString());
            }
            return sb.ToString();
        }
    }
}
