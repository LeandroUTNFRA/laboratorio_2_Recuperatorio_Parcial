﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Empleado
    {

        protected TimeSpan horaEgreso;
        protected TimeSpan horaIngreso;
        protected string legajo;
        protected string nombre;

        protected Empleado(  string legajo, string nombre,TimeSpan horaIngreso)
        {
            
            this.horaIngreso = horaIngreso;
            this.legajo = legajo;
            this.nombre = nombre;
        }

        public TimeSpan HoraIngreso
        {
            get
            {
                return this.horaIngreso;
            }
        }

        public TimeSpan HoraEgreso
        {
            get
            {
                return this.horaEgreso;
            }
            set
            {
                this.horaEgreso = ValidarHoraEgreso(value);
            }
        }

        public string Legajo
        {
            get
            {
                return this.legajo;
            }
        }

        public string Nombre
        {
            get
            {
                return this.nombre;
            }
        }


        public abstract string EmitirFactura();

        private TimeSpan ValidarHoraEgreso(TimeSpan horaEgreso)
        {
            if (horaEgreso> this.horaIngreso)
            {
                return this.horaEgreso;
            }

            return DateTime.Now.TimeOfDay;
        }

        protected double Facturar()
        {
            return (HoraEgreso - HoraIngreso).TotalHours;
        }


        public static bool operator ==(Empleado e1, Empleado e2)
        {
            if (!(e1 is null || e2 is null))
            {
                return (e1.horaEgreso == e2.horaEgreso && e1.horaIngreso == e2.horaIngreso && e1.nombre == e2.nombre && e1.legajo== e2.legajo);
            }
            return false;


        }

        public static bool operator !=(Empleado e1, Empleado e2)
        {
            return !(e1 == e2);
        }

    }
}
