﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Rac :Empleado
    {
        public enum EGrupo
        {
            CALL_IN,
            CALL_OUT,
            RRSS
        }

        private EGrupo grupo;
        private static double valorHora;

        static Rac()
        {
            valorHora = 875.90F;
        }

        public Rac(string legajo, string nombre, TimeSpan horaIngreso)
        : base(legajo, nombre, horaIngreso)
        {
            this.grupo = EGrupo.CALL_IN; 
        }

        public Rac(string legajo, string nombre, TimeSpan horaIngreso, EGrupo grupo)
            : base( legajo, nombre, horaIngreso)
        {
            this.grupo = grupo;
        }

        public EGrupo Grupo
        {
            get { return this.grupo; }
        }

        public static double ValorHora
        {
            get { return valorHora; }
            set
            {
                if (value > 0)
                {
                    valorHora = value;
                }
            }
        }

        public override string EmitirFactura()
        {
            return $"Factura de: {this.ToString()}\nImporte a facturar: {Facturar()}";
        }

        private double CalcularBonoGrupo()
        {
            switch (grupo)
            {
                case EGrupo.CALL_OUT:
                    return 0.1;
                case EGrupo.RRSS:
                    return 0.2;
                default:
                    return 0;
            }
        }

        protected double Facturar()
        {
            double totalHoras = base.Facturar();
            double bono = CalcularBonoGrupo();
            return totalHoras * valorHora * (1 + bono);
        }
        public override string ToString()
        {
            return $"{this.GetType().Name} - {grupo} - {legajo} - {nombre}";
        }

    }
}
