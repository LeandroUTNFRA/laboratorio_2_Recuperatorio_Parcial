﻿using System.Globalization;

namespace Entidades
{
    public class Supervisor:Empleado
    {
        private static float valorHora;

        static Supervisor()
        {
            valorHora = 1025.50F;
        }

        private Supervisor(string legajo) : base(legajo, "N/A",new TimeSpan(09, 00, 00))
        {

        }
        public Supervisor(string legajo, string nombre, TimeSpan horaIngreso) : base(legajo, nombre, horaIngreso)
        {

        }

        public static float ValorHora
        {
            get => valorHora;
            set
            {
                if (value > 0)
                {
                    valorHora = value;
                }
            }
        }

        public static implicit operator Supervisor(string legajo)
        {
            return new Supervisor(legajo);
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} - {legajo} - {nombre}";
        }

        public override string EmitirFactura()
        {
            return $"Factura de: {this.ToString()}\nImporte a facturar: {Facturar()}";
        }

        protected float Facturar()
        {
            return (float)(Facturar() * valorHora);
        }
    }
}